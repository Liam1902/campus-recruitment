import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-haeder',
  templateUrl: './haeder.component.html',
  styleUrls: ['./haeder.component.css']
})
export class HaederComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
